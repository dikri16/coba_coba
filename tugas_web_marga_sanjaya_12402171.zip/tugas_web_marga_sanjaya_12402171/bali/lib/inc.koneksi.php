<?php
$my['host']        = "localhost";
$my['user']        = "root";
$my['pass']        = "";
$my['dbs']        = "bali";

$koneksi        = mysql_connect($my['host'], $my['user'], $my['pass']);
if (! $koneksi) {
  echo "Gagal koneksi boss..!";
  mysql_error();
}
// memilih database pda server
mysql_select_db($my['dbs'])
         or die ("Database nggak ada tuh".mysql_error());

?>