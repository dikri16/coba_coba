<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>


<div id="bg">
</div>
<div id="main">
<div id="header">
        <div style="height: 40px;">
    </div>

        <div id="logo">

    </div>
    <div id="buttons">
      <a href="index.html" class="but"  title="">Home</a>
      <a href="Kesenian_Bali.html" class="but" title="">Kesenian Bali </a>
      <a href="Pariwisata.html"  class="but" title="">Pariwisata</a>
      <a href="Buku_tamu.php" class="but" title="">Buku Tamu</a>
    </div>
</div>
                        <div id="content_top"></div>
                               <div id="content">
                        <div style=" height:2px"></div>

                        <div id="center">
                          <h2>
                              <center>
                          </h2>
						  <form action="Buku_tamu_sim.php" method="post" name="form1" target="_self">
                                                        <table width="788" border="2">
                              <tr>
                                <td width="69">Nama</td>
                                <td width="701"><input class="input_txt2" value="" name="Txt_nama" type="text" /></td>
                              </tr>
                              <tr>
                                <td>Email</td>
                                <td><input class="input_txt2" value="" name="Txt_email" type="text" /></td>
                              </tr>
                              <tr>
                                <td>Pesan </td>
                                <td><textarea class="text_area2" cols="30" rows="3" name="Txt_komentar"></textarea></td>
                              </tr>
                            </table>
							
            <div></div>
                                  <div style="height:5px"></div>
        <div></div>
          <div style="height:5px"></div>
        <div></div>
                                  <div style="height:10px"></div>

        <div>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="submit2" name="TbSimpan" type="submit" value="Save" />
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="submit2" name="Submit2" type="reset" value="reset" />
        </div>
                          </form>

                     </div>

                </div>

</div>

</body>
</html>