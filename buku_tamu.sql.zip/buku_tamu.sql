-- phpMyAdmin SQL Dump
-- version 2.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2013 at 08:55 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `bali`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku_tamu`
--

CREATE TABLE `buku_tamu` (
  `id_btamu` int(11) NOT NULL auto_increment,
  `Nama` varchar(40) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `komentar` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY  (`id_btamu`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `buku_tamu`
--

INSERT INTO `buku_tamu` (`id_btamu`, `Nama`, `Email`, `komentar`, `tanggal`) VALUES
(2, 'dedi', 'rahasia2012@yahoo.com', 'sahabat', '2011-01-22'),
(3, 'margame', 'marga.sanjaya.tk.a@gmail.com', 'test 123', '2013-03-23'),
(4, 'azzam', 'azzam@gmail.com', '12345678979', '2013-03-23');
